package com.miempresa.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySistemaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
