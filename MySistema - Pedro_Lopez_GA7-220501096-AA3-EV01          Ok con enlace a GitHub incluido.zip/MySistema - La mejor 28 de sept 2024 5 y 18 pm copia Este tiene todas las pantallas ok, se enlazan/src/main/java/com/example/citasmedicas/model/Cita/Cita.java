package com.example.citasmedicas.model.Cita;

import java.time.LocalDateTime;

import com.example.citasmedicas.model.Medico;
import com.example.citasmedicas.model.Usuario.Usuario;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Cita {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	private Usuario usuario;

	@ManyToOne
	private Medico medico;

	private LocalDateTime fecha;
	
	


	public Cita(Long id, Usuario usuario, Medico medico, LocalDateTime fecha) {
		super();
		this.id = id;
		this.usuario = usuario;
		this.medico = medico;
		this.fecha = fecha;
	}
	
	public Cita() {
		// TODO Auto-generated constructor stub
	}

	// Getters y Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public LocalDateTime getFecha() {
		return fecha;
	}

	public void setFecha(LocalDateTime fecha) {
		this.fecha = fecha;
	}

	public Object getFechaHora() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setFechaHora(Object fechaHora) {
		// TODO Auto-generated method stub
		
	}

	public void setFormattedFecha1(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setFormattedFecha11(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setFormattedFecha(String format) {
		// TODO Auto-generated method stub
		
	}

}



