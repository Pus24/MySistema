package com.example.citasmedicas.controller;

import java.util.List;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.citasmedicas.model.Medico;
import com.example.citasmedicas.model.Cita.Cita;
import com.example.citasmedicas.model.Usuario.Usuario;
import com.example.citasmedicas.repository.UsuarioRepository.UsuarioRepository;
import com.example.citasmedicas.service.Cita.CitaService;
import com.example.citasmedicas.service.Medico.MedicoService;

@Controller
public class AuthController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CitaService citaService;

    @Autowired
    private MedicoService medicoService;

    // Mostrar formulario de registro
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "register";
    }

    // Registrar un usuario y redirigir a inicio de sesión
    @PostMapping("/register")
    public String registerUser(@ModelAttribute Usuario usuario, RedirectAttributes redirectAttributes) {
        usuarioRepository.save(usuario);
        redirectAttributes.addFlashAttribute("successMessage", "Registro exitoso. Ahora puede iniciar sesión.");
        return "redirect:/login";
    }

    // Mostrar formulario de inicio de sesión
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // Procesar inicio de sesión y redirigir a la página de citas
    @PostMapping("/login")
    public String processLogin(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("welcomeMessage", "Bienvenido. Puede agendar citas.");
        return "redirect:/citas";
    }

    // Mostrar formulario para agendar cita con médicos disponibles
    @GetMapping("/citas")
    public String mostrarFormularioCita(Model model) {
        // Obtén la lista de médicos desde el servicio
        List<Medico> medicos = medicoService.listar();

        // Debugging: Imprimir la lista de médicos en la consola
        System.out.println("Lista de médicos: " + medicos);

        // Añadir la lista de médicos al modelo
        model.addAttribute("medicos", medicos);

        return "citas"; // Redirige a la página de agendar citas médicas
    }

    // Procesar la cita médica
    @PostMapping("/citas")
    public String agendarCita(@ModelAttribute Cita cita, RedirectAttributes redirectAttributes) {
        try {
            citaService.guardarCita(cita);
            redirectAttributes.addFlashAttribute("successMessage", "Cita agendada exitosamente.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Hubo un error al agendar la cita.");
        }
        return "redirect:/mis-citas";
    }
   
    // Mostrar todas las citas reservadas
    @GetMapping("/mis-citas")
    public String listarMisCitas(Model model) {
        List<Cita> citas = citaService.listarCitas(); // Obtiene la lista de citas desde el servicio

        // Debug: Verificar que las citas y médicos están bien formateados
        for (Cita cita : citas) {
            System.out.println("Cita ID: " + cita.getId() + ", Médico: " + (cita.getMedico() != null ? cita.getMedico().getNombre() : "Sin médico"));
        }

        // Agregar las citas y médicos al modelo
        model.addAttribute("citas", citas);
        model.addAttribute("medicos", medicoService.listar()); // Asegúrate de que también agregas los médicos
    
        return "mis-citas";
    }
    
    public String mostrarCitas(Model model) {
        List<Cita> citas = citaService.obtenerCitas();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Cita cita : citas) {
            if (cita.getFecha() != null) {
                cita.setFormattedFecha(cita.getFecha().format(formatter));
            } else {
                cita.setFormattedFecha("Fecha no disponible");
            }
        }

        model.addAttribute("citas", citas);
        return "mis-citas";
    }
    
    // Manejar la edición de una cita
    @PostMapping("/editar-cita/{id}")
    public String editarCita(@PathVariable Long id, @ModelAttribute Cita cita, RedirectAttributes redirectAttributes) {
        Cita citaExistente = citaService.obtenerCitaPorId(id);
        if (citaExistente != null) {
            citaExistente.setMedico(cita.getMedico());
            citaExistente.setFecha(cita.getFecha());
            citaService.guardarCita(citaExistente);
            redirectAttributes.addFlashAttribute("successMessage", "Cita editada exitosamente.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Cita no encontrada.");
        }
        return "redirect:/mis-citas";
    }

    // Manejar la eliminación de una cita
    @PostMapping("/eliminar-cita/{id}")
    public String eliminarCita(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        citaService.eliminarCita(id);
        redirectAttributes.addFlashAttribute("successMessage", "Cita eliminada exitosamente.");
        return "redirect:/mis-citas";
    }

    // Manejar el guardado de una cita después de edición
    @PostMapping("/guardar-cita/{id}")
    public String guardarCita(@PathVariable Long id, @ModelAttribute Cita cita, RedirectAttributes redirectAttributes) {
        Cita citaExistente = citaService.obtenerCitaPorId(id);
        if (citaExistente != null) {
            citaExistente.setMedico(cita.getMedico());
            citaExistente.setFecha(cita.getFecha());
            citaService.guardarCita(citaExistente);
            redirectAttributes.addFlashAttribute("successMessage", "Cita guardada exitosamente.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Cita no encontrada.");
        }
        return "redirect:/mis-citas";
    }
}
