package com.example.citasmedicas.service.Cita;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.citasmedicas.model.Cita.Cita;
import com.example.citasmedicas.repository.CitaRepository.CitaRepository;

@Service
public class CitaService {

    @Autowired
    private CitaRepository citaRepository;

    // Método para listar todas las citas
    public List<Cita> listarCitas() {
        return citaRepository.findAll();  // Retorna todas las citas desde el repositorio
    }

    // Método para guardar una cita
    public void guardarCita(Cita cita) {
        citaRepository.save(cita);
    }

    // Obtener una cita por su ID
    public Cita obtenerCitaPorId(Long id) {
        return citaRepository.findById(id).orElse(null);
    }

    // Actualizar una cita existente
    public Cita actualizarCita(Long id, Cita citaDetalles) {
        Optional<Cita> citaOptional = citaRepository.findById(id);
        if (citaOptional.isPresent()) {
            Cita citaExistente = citaOptional.get();
            citaExistente.setFecha(citaDetalles.getFecha());
            citaExistente.setMedico(citaDetalles.getMedico());
            citaExistente.setUsuario(citaDetalles.getUsuario());
            return citaRepository.save(citaExistente);
        }
        return null;
    }

    // Eliminar una cita por su ID
    public void eliminarCita(Long id) {
        citaRepository.deleteById(id);
    }

	public List<Cita> obtenerCitas() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Cita> obtenerCitas1() {
		// TODO Auto-generated method stub
		return null;
	}
}
