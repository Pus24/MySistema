package com.example.citasmedicas.service.Medico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.citasmedicas.model.Medico;
import com.example.citasmedicas.repository.MedicoRepository.MedicoRepository;

@Service
public class MedicoService {

    @Autowired
    private MedicoRepository medicoRepository;
    
    // Obtener todos los médicos
    public List<Medico> listar() {
        List<Medico> medicos = medicoRepository.findAll();
        System.out.println("Médicos obtenidos: " + medicos);  // Imprimir los médicos
        return medicos;
    }

    public List<Medico> getAllMedicos() {
        return medicoRepository.findAll();
    }

    public Optional<Medico> getMedicoById(Long id) {
        return medicoRepository.findById(id);
    }

    public Medico saveMedico(Medico medico) {
        return medicoRepository.save(medico);
    }

    public Medico updateMedico(Long id, Medico medicoDetails) {
        Optional<Medico> medico = medicoRepository.findById(id);
        if (medico.isPresent()) {
            Medico updatedMedico = medico.get();
            updatedMedico.setNombre(medicoDetails.getNombre());
            updatedMedico.setEspecialidad(medicoDetails.getEspecialidad());
            return medicoRepository.save(updatedMedico);
        }
        return null;
    }

    public void deleteMedico(Long id) {
        medicoRepository.deleteById(id);
    }
}
