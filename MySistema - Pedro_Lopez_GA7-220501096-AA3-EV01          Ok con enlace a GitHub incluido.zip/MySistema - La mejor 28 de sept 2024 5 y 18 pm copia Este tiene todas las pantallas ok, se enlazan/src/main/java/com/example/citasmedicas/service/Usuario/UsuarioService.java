package com.example.citasmedicas.service.Usuario;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.citasmedicas.model.Usuario.Usuario;
import com.example.citasmedicas.repository.UsuarioRepository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Eliminado el uso de PasswordEncoder

    public void registrarUsuario(Usuario usuario) {
        // Elimina el cifrado de contraseñas
        usuarioRepository.save(usuario);
    }

    public Optional<Usuario> getUsuarioById(Long id) {
        return usuarioRepository.findById(id);
    }

    public void updateUsuario(Long id, Usuario usuarioDetails) {
        Optional<Usuario> usuario = usuarioRepository.findById(id);
        if (usuario.isPresent()) {
            Usuario updatedUsuario = usuario.get();
            updatedUsuario.setUsername(usuarioDetails.getUsername());
            // No se encripta la contraseña
            updatedUsuario.setPassword(usuarioDetails.getPassword());
            updatedUsuario.setTelefono(usuarioDetails.getTelefono());
            updatedUsuario.setCorreo(usuarioDetails.getCorreo());
            updatedUsuario.setDireccion(usuarioDetails.getDireccion());
            usuarioRepository.save(updatedUsuario);
        }
    }

    public void deleteUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }

    public Usuario findByUsername(String name) {
        // Implementar la búsqueda de usuario por nombre
        return null; // Modificar la lógica según sea necesario
    }

    public void update(Long id, Usuario paciente) {
        // Implementar lógica de actualización si es necesario
    }

    public Usuario findById(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public void delete(Long id) {
        usuarioRepository.deleteById(id);
    }

    public Object findAll() {
        return usuarioRepository.findAll();
    }

    public void save(Usuario existingUser) {
        usuarioRepository.save(existingUser);
    }
}
