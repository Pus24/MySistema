package com.exmple.citasmedicas.MedicoController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.citasmedicas.model.Medico;

@Controller
public class MedicoController {

	@Autowired
	private com.example.citasmedicas.repository.MedicoRepository.MedicoRepository medicoRepository;

	@GetMapping("/medicos")
	public String listarMedicos(Model model) {
		List<Medico> listaMedicos = medicoRepository.findAll();
		model.addAttribute("medicos", listaMedicos);
		return "medicos";
	}
}
